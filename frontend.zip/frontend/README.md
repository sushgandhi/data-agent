# Data Flow Agent Frontend

This is a simple ChatGPT-like frontend for the Data Flow Agent API.

## Features

- File upload interface
- Chat-based interaction with the API
- Support for displaying tables and visualizations
- Chat history management
- Responsive design

## Installation

```bash
# Install dependencies
npm install
```

## Usage

First, make sure the backend API is running:

```bash
# From the root directory
uvicorn api:app --reload --host 0.0.0.0 --port 8000
```

Then, start the frontend server:

```bash
# From the frontend directory
npm start
```

The frontend will be available at http://localhost:3000.

## How It Works

- The frontend server (Express) serves the static files and proxies API requests to the backend
- API requests are sent to `/api/*` which is then forwarded to `http://localhost:8000/*`
- File uploads are handled by the backend API
- All user interactions are kept in the browser using localStorage

## How to Use

1. Upload a CSV or Excel file using the sidebar
2. Ask questions about your data in natural language
3. View the results in the chat interface, including tables and visualizations

## Technologies Used

- HTML5/CSS3
- JavaScript (ES6+)
- Express.js (for serving static files and API proxy)
- http-proxy-middleware (for API forwarding)
- LocalStorage (for persisting state)

## Troubleshooting

- If plots are not appearing, make sure the backend API server is running and accessible
- If you see "Image Load Failed" messages, check the browser console for more details
- For API errors, check both the frontend and backend console logs 